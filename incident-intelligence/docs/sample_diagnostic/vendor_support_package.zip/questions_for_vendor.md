# SYNTHETIC DEMONSTRATION — NOT CUSTOMER DATA

1. Does the synthetic chronology match expected door behavior?
2. Which missing controller trace would confirm or reject the leading hypothesis?
